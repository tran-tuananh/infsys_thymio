package helper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Reader {

	private String readPath = "";
	private Writer wRaw;
	private Writer wDisc;
	private static final String DATATYPE = ".csv";
	private static final String[] DATA = { "ecke", "kante", "frontal" };

	private DataCalc calc;

	public Reader(String readPath, Writer wRaw, Writer wDisc) { 
		this.wRaw = wRaw;
		this.wDisc = wDisc;
		this.readPath = readPath;
		calc = new DataCalc(wRaw, wDisc);
	}

	public void run() {
		read();
	}

	private void read() {
		try {
			readInData();
		} catch (IOException e) {
			System.out.println("Couldn't read in Data " + e);
		}
	}

	private void readInData() throws IOException {
		for (int i = 0; i < DATA.length; i++) {
			String file = readPath + DATA[i] + DATATYPE;
			System.out.println("File: " + file);
			FileReader in = new FileReader(file);
			BufferedReader br = new BufferedReader(in);

			String line = "";
			line = br.readLine();
			while (line != null) {
				line = br.readLine();
				if (line != null)
					calc.run(line, DATA[i].toUpperCase());
			}
		in.close();
		}
	}
}
