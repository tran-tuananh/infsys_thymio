package main;

import helper.Reader;
import helper.Writer;

/*
 * Args:	1. Path to Folder (contains "kante.csv, ecke.csv, frontal.csv)
 * 			2. 0 for Raw Output - 1 for discrete Output
 * 
 * TODO: Write a method to discrete the Values  
 */
 
public class MainController {
	
	private static final int RAW = 0;
	private static final int DISCRETE = 1;

	private String readPath = "";
	private String writeRawFile = "data_raw.arff";
	private String writeDiscreteFile = "data_discrete.arff";
	private String writePath = "";


	public MainController(String readPath) {
		this.readPath = readPath;
	}

	public static void main(String[] args) {
		MainController mc = new MainController(args[0]);
		mc.run();
	}

	private void run() {
		Writer wRaw = new Writer(readPath + writeRawFile);
		Writer wDiscrete = new Writer(readPath + writeDiscreteFile);
		Reader r = new Reader(readPath, wRaw, wDiscrete);
		r.run();
	}

}
