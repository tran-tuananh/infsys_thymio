package helper;

import java.io.FileWriter;
import java.io.IOException;

public class Writer {

	private static final String HEAD = "@relation data\n\n@attribute Label {ECKE,FRONTAL,KANTE}\n@attribute AngleLeft numeric\n@attribute DistLeft numeric\n@attribute AngleRight numeric\n@attribute DistRight numeric\n\n@data\n";

	private String writePath = "";

	private FileWriter wr;

	public Writer(String writePath) {
		this.writePath = writePath;
		initWriter();
		writeLine(HEAD);
	}

	public void writeLine(String line) {
		try {
			write(line);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	

	private void initWriter() {
		try {
			wr = new FileWriter(writePath);
		} catch (IOException e) {
			System.out.println("Error: " + e
					+ " - Could not init FileWriter with given Path.");
			e.printStackTrace();
		}
	}

	public void write(String writeThis) throws IOException {
		wr.append(writeThis);
		wr.flush();
	}

	public void closeWriter() {
		try {
			wr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
